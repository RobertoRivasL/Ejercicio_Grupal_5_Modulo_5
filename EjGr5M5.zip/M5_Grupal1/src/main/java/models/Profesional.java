package models;

public class Profesional {
}
